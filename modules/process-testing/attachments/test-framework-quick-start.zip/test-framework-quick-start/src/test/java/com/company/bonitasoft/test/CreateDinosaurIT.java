package com.company.bonitasoft.test;

import static com.bonitasoft.test.toolkit.predicate.ProcessInstancePredicates.containsPendingUserTasks;
import static com.bonitasoft.test.toolkit.predicate.ProcessInstancePredicates.processInstanceArchived;
import static com.bonitasoft.test.toolkit.predicate.ProcessInstancePredicates.processInstanceStarted;
import static com.bonitasoft.test.toolkit.predicate.TaskPredicates.hasCandidates;
import static com.bonitasoft.test.toolkit.predicate.TaskPredicates.taskArchived;
import static com.bonitasoft.test.toolkit.predicate.TaskPredicates.taskReady;
import static org.assertj.core.api.Assertions.assertThat;
import static org.awaitility.Awaitility.await;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.RegisterExtension;

import com.bonitasoft.test.toolkit.BonitaTestToolkit;
import com.bonitasoft.test.toolkit.contract.ComplexInputBuilder;
import com.bonitasoft.test.toolkit.contract.ContractBuilder;
import com.bonitasoft.test.toolkit.junit.extension.BonitaTestExtension;
import com.bonitasoft.test.toolkit.junit.extension.BonitaTestExtension.Configuration;
import com.bonitasoft.test.toolkit.model.BusinessData;
import com.bonitasoft.test.toolkit.model.QueryResult;
import com.bonitasoft.test.toolkit.model.Task;

class CreateDinosaurIT {

    @RegisterExtension
    static BonitaTestExtension bonitaExtension = new BonitaTestExtension(Configuration.builder()
            .deleteProcessInstances()
            .clearBDM()
            .build());

    @Test
    void should_create_an_hungry_tyrannosaurus(BonitaTestToolkit toolkit) throws Exception {
        var user = toolkit.getUser("walter.bates");
        var processDef = toolkit.getProcessDefinition("create-dinosaur");
        var businessObject = toolkit.getBusinessOject("com.company.bonitasoft.model.Dinosaur");

        assertThat(businessObject.findAll(0, 10)).isEmpty();

        var processInstance = processDef.startProcessFor(user);

        await().until(processInstance, processInstanceStarted()
                .and(containsPendingUserTasks("CreateDinosaur")));

        var complexInputBuilder = ComplexInputBuilder.complexInput()
                .textInput("name", "Tyrannosaurus")
                .textInput("color", "Brown")
                .booleanInput("hungry", true);
        var task1Contract = ContractBuilder.newContract().complexInput("dinosaurInput", complexInputBuilder).build();
        var task1 = processInstance.getFirstPendingUserTask("CreateDinosaur");

        await().until(task1, hasCandidates(user)
                .and(taskReady()));

        task1.execute(user, task1Contract);

        await().until(task1, taskArchived());
        await().until(processInstance, processInstanceArchived());
        assertThat(processInstance.searchTasks()).map(Task::getName).containsExactlyInAnyOrder("CreateDinosaur", "goToHunt");
        assertThat(processInstance.getFirstTask("goToHunt").isArchived()).isTrue();

        // Data assertions
        QueryResult queryResult = businessObject.query("findByName", List.of("name=Tyrannosaurus"), 0, 10);
        List<BusinessData> businessData = queryResult.getResults();
        assertThat(businessData).hasSize(1);
        assertThat(businessData.get(0).getStringField("name")).isEqualTo("Tyrannosaurus");
        assertThat(businessData.get(0).getStringField("color")).isEqualTo("Brown");
        assertThat(businessData.get(0).getBooleanField("hungry")).isTrue();
    }

}
